return this['SQL'];
})();
if (typeof module !== 'undefined') module.exports = SQL;
if (typeof define === 'function') define(SQL);
