#rm js/sql.js
EMSCRIPTEN=/home/olojkine/Téléchargements/emscripten/emscripten/ make $1
